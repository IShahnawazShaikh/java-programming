
public class Course {
	int courseId;
	  String Name;
	public Course(int id, String name2) {
		this.courseId=id;
		this.Name=name2;
	}
	public void display(){
		  System.out.println("Course Name= "+Name);
		  System.out.println("Course ID= "+courseId);
		
	}

  
}
