package pack2;
import pack1.Day;            //normal import
//import static pack1.Day.TUES;     //static import
   //or
import static pack1.Day.*;
public class test2
{
	 public static void main(String...v){
		  
		   System.out.println(Day.MON);
		   System.out.println(TUES);
           System.out.println(MON);

	 }
}