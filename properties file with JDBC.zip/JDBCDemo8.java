import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;
public class JDBCDemo8 {

	public static void main(String[] args) throws IOException,FileNotFoundException {
		FileInputStream fis=new FileInputStream("src/myFile.properties");
		Properties p=new Properties();
		p.load(fis);
		System.out.println("Data of Properties file are:="+p.toString());
		System.out.println("Value on the basis of propery="+p.getProperty("Name"));
	}

}
