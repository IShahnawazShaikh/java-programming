import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Properties;
public class JDBCDemo9 {
	public static void main(String[] args) throws SQLException, FileNotFoundException, IOException {
		Properties p=new Properties();
		FileInputStream fis=new FileInputStream("src/myFile2.properties");
		p.load(fis);
		String query="SELECT * from Student";
		try(Connection con=DriverManager.getConnection(p.getProperty("url"),p)){
		   PreparedStatement ps=con.prepareStatement(query);
		   ResultSet rs=ps.executeQuery();
		   ResultSetMetaData rsmd= rs.getMetaData();
		   for(int i=1;i<=rsmd.getColumnCount();i++)
		    System.out.print(rsmd.getColumnName(i)+"\t");
		   System.out.println();
		   while(rs.next()){
			  System.out.println(rs.getInt(1)+"\t"+rs.getString(2)+"\t"+rs.getInt(3)+"\t"+rs.getInt(4)+"\t"+rs.getInt(5));  
		   }
		}
		catch(Exception ex){
			ex.printStackTrace();
		}
		
	}

}
