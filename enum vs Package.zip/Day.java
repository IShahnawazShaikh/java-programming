package pack1;
public enum Day{
 SUN,MON,TUES;
}