import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Application {
	public static void main(String[] args) {
		ApplicationContext context=new ClassPathXmlApplicationContext("spring_config.xml");
		Student student1=context.getBean("student1",Student.class);
		Course courseObject=context.getBean("courseObject",Course.class);
		courseObject.display();
		student1.display();
	}

}
