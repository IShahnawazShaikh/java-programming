package pack2;
import pack1.Day;      //Normal Import
      //OR
// import pack1.*;
public class test1
{
	public static void main(String...c){
         Day d=Day.TUES;
		 System.out.println(d);
	}
}