package pack3;
//import static pack1.Day.MON;    //static import
//or
import static pack1.Day.*;
public class test3
{
	 public static void main(String...x){
		 System.out.println(MON);
	 }
}