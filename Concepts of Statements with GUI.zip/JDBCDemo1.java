import java.awt.Image;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
public class JDBCDemo1 {
	Connection con=null;
	Statement st1,st2;
	JFrame frame;
	JButton b1,b2;
	JLabel l1,l2,l3,l4,l5,l6,l7;
	JTextField f1,f2,f3,f4,f5,f6,f7;
	JDBCDemo1() throws SQLException{
		con=JDBCConnection.myConnection();
		st1=con.createStatement();
		frame=new JFrame("Student Panel");
		frame.setSize(450,540);
		frame.setLayout(null);
		l1=new JLabel();
		l1.setText("Student ID:");
		l1.setBounds(20, 50,100, 30);
		frame.add(l1);
		f1=new JTextField();
		f1.setBounds(120, 50, 100, 30);
		frame.add(f1);
		b1=new JButton("get Details");
		b1.setBounds(250,50,100,30);
		frame.add(b1);
		
		 
		l2=new JLabel();
		l2.setText("Student details are:");
		l2.setBounds(100,130,200,30);
		frame.add(l2);
		
		l3=new JLabel();
		l3.setText("Student ID");
		l3.setBounds(20, 170,140, 30);
		frame.add(l3);
		f2=new JTextField();
		f2.setBounds(150, 170, 100, 30);
		frame.add(f2);
		
		l4=new JLabel();
		l4.setText("Student Name");
		l4.setBounds(20, 210,140, 30);
		frame.add(l4);
		f3=new JTextField();
		f3.setBounds(150, 210, 100, 30);
		frame.add(f3);
		
		
		l5=new JLabel();
		l5.setText("Java Marks");
		l5.setBounds(20, 250,140, 30);
		frame.add(l5);
		f4=new JTextField();
		f4.setBounds(150, 250, 100, 30);
		frame.add(f4);
		
		l6=new JLabel();
		l6.setText("Node.js Marks");
		l6.setBounds(20, 290,140, 30);
		frame.add(l6);
		f5=new JTextField();
		f5.setBounds(150, 290, 100, 30);
		frame.add(f5);
		
		l7=new JLabel();
		l7.setText("DS Marks");
		l7.setBounds(20, 330,140, 30);
		frame.add(l7);
		f6=new JTextField();
		f6.setBounds(150, 330, 100, 30);
		frame.add(f6);
		
		b2=new JButton("Result");
		b2.setBounds(85,380,90,30);
		frame.add(b2);
		
		f7=new JTextField();
		f7.setBounds(150, 420, 100, 30);
		frame.add(f7);
		
		
		b1.addActionListener(e->{
			 try {
				ResultSet rs=st1.executeQuery("SELECT * from Student");
				while(rs.next()){
					if(f1.getText().equals(""+rs.getInt(1))){
						 f2.setText(""+rs.getInt(1));
						 f3.setText(rs.getString(2));
						 f4.setText(""+rs.getInt(3));
						 f5.setText(""+rs.getInt(4));
						 f6.setText(""+rs.getInt(5));
					}
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		 });
	   b2.addActionListener(e->{
			String query="{call GET_PERCENT(?,?)}";
			  try {
				CallableStatement cs=con.prepareCall(query);
				 cs.setInt(1,Integer.parseInt(f1.getText()));
				  cs.registerOutParameter(2,Types.VARCHAR);
				cs.execute();
				f7.setText(cs.getString(2));
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		});
		frame.setVisible(true);
	}
  public static void main(String...x ) throws ClassNotFoundException, SQLException{
	  new JDBCDemo1();
  }
}
