
public class Student {
	int Id;
	String Name;
	Student(int id,String name){
		this.Id=id;
		this.Name=name;
	}
	public void display(){
		 System.out.println("Name Of the Student = "+Name);
		 System.out.println("Id Of the Student = "+Id);
	}
	public static Course getInstance(int id,String name){
		 return new Course(id,name);
	}
}
